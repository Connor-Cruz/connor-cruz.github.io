package Project;

import java.awt.*;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLayeredPane;

public class FamilyControlsGUI {
    private final JFrame frame;
    private JLayeredPane layeredPane;

    public FamilyControlsGUI(MasterFrame window) {
        frame = window.frame;
    }

    public void setup() {
        // Set up the frame properties
        frame.getContentPane().removeAll();  // Clear existing components

        // Initialize JLayeredPane and set its bounds
        layeredPane = new JLayeredPane();
        layeredPane.setPreferredSize(new Dimension(frame.getWidth(), frame.getHeight()));
        layeredPane.setBounds(0, 0, frame.getWidth(), frame.getHeight());  // Set size to fill the frame

        // Menu button in the top right corner
        JButton menuButton = new MenuButton("MainMenu", "setup", "MAIN MENU");
        menuButton.setBounds(frame.getWidth() - 150, 10, 130, 50);
        layeredPane.add(menuButton);

        JButton fileMod = new MenuButton("FileModifier", "setup", "File Modifier");
        fileMod.setBounds(50, 10, 200, 100);
        layeredPane.add(fileMod, JLayeredPane.DEFAULT_LAYER);

        // Add the layered pane to the frame and refresh the display
        frame.add(layeredPane);
        frame.pack();
        frame.revalidate();
        frame.repaint();
    }
}
