package Project;

public final class Main {
    private static MasterFrame window;

    public static void main(String[] args) {
        window = new MasterFrame();
        MenuNavigator.initialize(window);
        MenuGUI menu = new MenuGUI(window);
        MenuNavigator.addObject("MainMenu", menu);
        FileModifierGUI fileGUI = new FileModifierGUI(window);
        MenuNavigator.addObject("FileModifier", fileGUI);
        ImageLibraryGUI imageGUI = new ImageLibraryGUI(window);
        MenuNavigator.addObject("ImageLibrary", imageGUI);
        FamilyControlsGUI familyGUI = new FamilyControlsGUI(window);
        MenuNavigator.addObject("FamilyControls", familyGUI);
        menu.setup();
    }
}