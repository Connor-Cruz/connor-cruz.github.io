package Project;

import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Person {
    final private List<BufferedImage> images = new ArrayList<>();  // List to store images for the person
    public String name;  // Name of the person

    // Constructor to initialize the person with their name
    public Person(String name) {
        this.name = name;
    }

    // Method to add an image to the person's image list
    public void insertImage(BufferedImage image) {
        images.add(image);
    }

    // Method to get the number of images associated with the person
    public int getImageAmount() {
        return images.size();
    }

    // Method to retrieve a specific image by index
    public BufferedImage getImage(int ind) {
        return images.get(ind);
    }

    public List<BufferedImage> getImages() {
        return images;
    }

    public BufferedImage getRandomImage() {
        return images.get(new Random().nextInt(images.size()));
    }
}