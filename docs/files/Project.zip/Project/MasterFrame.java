package Project;

import java.awt.*;
import javax.swing.*;

public class MasterFrame {
    public JFrame frame;

    public MasterFrame() {
        frame = new JFrame("Dementia App");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setExtendedState(JFrame.MAXIMIZED_BOTH); 
        frame.setUndecorated(true);
        frame.setLayout(new BorderLayout());
        frame.setVisible(true);
        frame.setPreferredSize(new Dimension(1600, 1000)); // Example size
        frame.setVisible(true); // Ensure the frame is visible
    }

    public void updateContent(JPanel newPanel) {
        frame.getContentPane().removeAll();  // Remove existing components
        frame.getContentPane().add(newPanel);  // Add new components
        frame.revalidate();
        frame.repaint();
    }
    public void updateContent(JLayeredPane pane) {
        frame.removeAll();
        frame.add(pane, BorderLayout.CENTER);
        frame.revalidate();
        frame.repaint();
    }
    public void updateContent() {
        frame.getContentPane().removeAll();
        
        frame.revalidate();
        frame.repaint();
    }
}
