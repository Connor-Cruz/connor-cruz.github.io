package Project;

import java.lang.reflect.Method;
import java.util.HashMap;

/**
 * MenuNavigator is a utility class for managing navigation 
 * between different menus and game states in the application.
 */
public final class MenuNavigator {

    private static MasterFrame window; // The main application window
    private final static HashMap<String, Object> objects = new HashMap<>(); // Stores named objects for navigation

    // Private constructor to prevent instantiation
    private MenuNavigator() {}

    /**
     * Initializes the MenuNavigator with the main application frame.
     * 
     * @param frame the main application window
     */
    public static void initialize(MasterFrame frame) {
        window = frame;
    }

    /**
     * Navigates to a specific method in a target class, updating the main window content.
     * 
     * @param targetClass the target object to invoke the method on
     * @param methodName the name of the method to invoke
     * @param args the arguments to pass to the method
     */
    @SuppressWarnings("UseSpecificCatch")
    public static void navigateTo(Object targetClass, String methodName, Object... args) {
        window.updateContent(); // Clear or update the current content in the main frame
        try {
            // Get argument types for the specified method
            Class<?>[] argTypes = new Class[args.length];
            for (int i = 0; i < args.length; i++) {
                argTypes[i] = args[i].getClass();
            }

            // Locate the method and invoke it with arguments
            Method method = targetClass.getClass().getMethod(methodName, argTypes);
            method.invoke(targetClass, args);
        } catch (Exception e) {
            System.out.println("Error: Method " + methodName + " not found in " + targetClass.getClass().getName());
        }
    }

    /**
     * Adds an object to the object map with a specified name.
     * 
     * @param name the name of the object
     * @param obj the object to store
     */
    public static void addObject(String name, Object obj) {
        objects.put(name, obj);
    }

    /**
     * Checks if an object with the specified name exists in the object map.
     * 
     * @param name the name of the object
     * @return the object if it exists, or null otherwise
     */
    public static Object checkObject(String name) {
        return objects.get(name);
    }

    /**
     * Removes an object from the object map by its name.
     * 
     * @param name the name of the object to remove
     */
    public static void removeObject(String name) {
        objects.remove(name);
    }

    /**
     * Retrieves an object from the object map by its name.
     * 
     * @param name the name of the object
     * @return the retrieved object
     */
    public static Object getObject(String name) {
        return objects.get(name);
    }

    /**
     * Creates and stores a new CardGame instance with the specified difficulty.
     * 
     * @param diff the difficulty level of the card game
     */
    public static void createCardGame(int diff) {
        CardGame game = new CardGame(window, diff);
        removeObject("CardGame"); // Remove existing instance if present
        addObject("CardGame", game);
    }

    /**
     * Creates and stores a new QuizGameGUI instance with the specified difficulty.
     * 
     * @param diff the difficulty level of the quiz game
     */
    public static void createQuizGame(int diff) {
        QuizGameGUI game = new QuizGameGUI(window, diff);
        removeObject("QuizGame"); // Remove existing instance if present
        addObject("QuizGame", game);
    }

    /**
     * Creates and stores a new DiffSelectGUI instance for selecting game difficulty.
     * 
     * @param game the game type for which the difficulty is being selected
     */
    public static void createDiffSelect(int game) {
        DiffSelectGUI diffSelect = new DiffSelectGUI(window, game);
        removeObject("DiffSelect"); // Remove existing instance if present
        addObject("DiffSelect", diffSelect);
    }
}
