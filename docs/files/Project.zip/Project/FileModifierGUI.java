package Project;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.io.File;
import javax.swing.*;

public class FileModifierGUI {
    private final JFrame frame;
    private final FileModifier modifier;
    private JTextField personField;
    private JLayeredPane layeredPane;

    public FileModifierGUI(MasterFrame window) {
        modifier = new FileModifier();
        frame = window.frame;
    }

    public void setup() {
        // Set up the frame properties
        frame.getContentPane().removeAll();  // Clear existing components

        // Initialize JLayeredPane and set its bounds
        layeredPane = new JLayeredPane();
        layeredPane.setPreferredSize(new Dimension(frame.getWidth(), frame.getHeight()));
        layeredPane.setBounds(0, 0, frame.getWidth(), frame.getHeight());  // Set size to fill the frame
        
        // Input field and label for the person's name
        JLabel personLabel = new JLabel("Enter Person Name:");
        personLabel.setBounds(50, 50, 200, 30);
        
        personField = new JTextField(20);
        personField.setBounds(50, 90, 200, 30);

        // Button to add images
        JButton addImageButton = new JButton("Add Images");
        addImageButton.setBounds(50, 130, 150, 30);
        addImageButton.addActionListener((ActionEvent e) -> addImages());

        // Menu button in the top right corner
        JButton menuButton = new MenuButton("MainMenu", "setup", "MAIN MENU");
        menuButton.setBounds(50, 10, 130, 50);
        
        // Add components to the JLayeredPane with specified layers
        layeredPane.add(personLabel, JLayeredPane.DEFAULT_LAYER);
        layeredPane.add(personField, JLayeredPane.DEFAULT_LAYER);
        layeredPane.add(addImageButton, JLayeredPane.DEFAULT_LAYER);
        layeredPane.add(menuButton, JLayeredPane.PALETTE_LAYER);  // Add menu button to a higher layer

        // Add the layered pane to the frame and refresh the display
        frame.add(layeredPane);
        frame.pack();
        frame.revalidate();
        frame.repaint();
    }

    private void addImages() {
        String person = personField.getText();
        if (person.isEmpty()) {
            JOptionPane.showMessageDialog(frame, "Please enter a person's name.");
            return;
        }

        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Select Images");
        fileChooser.setMultiSelectionEnabled(true);
        fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
          
        int result = fileChooser.showOpenDialog(frame);
        
        if (result == JFileChooser.APPROVE_OPTION) {
            File[] selectedFiles = fileChooser.getSelectedFiles();
            
            for (File selectedFile : selectedFiles) {
                String filePath = selectedFile.getAbsolutePath().replace("\\", "/");
                
                if (isValidImageFile(filePath)) {
                    modifier.addImage(filePath, person);
                } else {
                    JOptionPane.showMessageDialog(frame, "Invalid file format for: " + selectedFile.getName());
                }
            }
            JOptionPane.showMessageDialog(frame, "Images added successfully.");
        }
    }

    // Method to validate image file formats (jpg, png, etc.)
    private boolean isValidImageFile(String filePath) {
        String[] validExtensions = {"jpg", "jpeg", "png", "gif", "bmp"};
        for (String ext : validExtensions) {
            if (filePath.toLowerCase().endsWith("." + ext)) {
                return true;
            }
        }
        return false;
    }
}
