package Project;

import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import javax.imageio.ImageIO;

public final class ImageLibrary {
    // List to store all Person objects, each representing a person with associated images
    public List<Person> people = new ArrayList<>();

    // Constructor that initializes the image assignment process
    public ImageLibrary() {
        assignImages();
    }

    // Method to read image paths from a text file and assign them to Person objects
    public void assignImages() {
        // Path to the data file containing person names and image paths
        String path = "C:/FabAcademy/CSA/Project/data.txt";
        
        // Read the data file line by line
        try (BufferedReader br = new BufferedReader(new FileReader(path))) {
            String line;
            Person currentPerson = null;

            // Loop through each line in the file
            while ((line = br.readLine()) != null) {
                line = line.trim();  // Remove leading/trailing whitespace

                // If the line starts with '#', it signifies a new person
                if (line.startsWith("#")) {
                    // If there's an existing person, add them to the people list
                    if (currentPerson != null) {
                        people.add(currentPerson);
                    }

                    // Create a new Person object with the name from the line
                    String personName = line.substring(1).trim();  // Remove the '#' and trim whitespace
                    currentPerson = new Person(personName);

                // If the line contains an image path and there's a current person, load the image
                } else if (!line.isEmpty() && currentPerson != null) {
                    try {
                        // Attempt to read the image from the specified path
                        BufferedImage image = ImageIO.read(new File(line));

                        // If image loading was successful, add it to the current person's images
                        if (image != null) {
                            currentPerson.insertImage(image);
                        } else {
                            System.out.println("ERROR: Couldn't read image at " + line);
                        }
                    } catch (IOException e) {
                        // Handle the case where the image file is not found or invalid
                        System.out.println("ERROR: Image file not found or invalid at path " + line);
                    }
                }
            }

            // After the loop, add the last person to the list if they exist
            if (currentPerson != null) {
                people.add(currentPerson);
            }

        } catch (IOException e) {
            // Handle the case where the data file couldn't be read
            System.out.println("ERROR: Could not read file at " + path);
        }
    }

    // Method to return the list of Person objects
    public List<Person> getPeople() {
        return people;
    }

    public Person getRandomPerson() {
        return people.get(new Random().nextInt(people.size()));
    }

    public List<String> getRandomNames(int amount) {
        List<Person> newList = new ArrayList<>(people);
        List<String> nameList = new ArrayList<>();
        for (int i = 0; i < amount; i++) {
            Person person = newList.get(new Random().nextInt(newList.size()));
            nameList.add(person.name);
            newList.remove(person);
        }
        return nameList;
    }

    public List<BufferedImage> getRandomImages(int amount) {
        List<Person> newList = new ArrayList<>(people);
        List<BufferedImage> imageList = new ArrayList<>();
        for (int i = 0; i < amount; i++) {
            Person person = newList.get(new Random().nextInt(newList.size()));
            imageList.add(person.getRandomImage());
            newList.remove(person);
        }
        return imageList;
    }
}