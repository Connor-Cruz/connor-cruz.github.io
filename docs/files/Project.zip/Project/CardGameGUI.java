package Project;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.List;
import javax.swing.*;

public class CardGameGUI {
    private final CardGame game;
    private final List<JButton> cardButtons;
    private ImageIcon resizedCardIcon;  // Store the resized card back icon

    private JLayeredPane layeredPane;
    private JLabel focusCard1, focusCard2, nameLabel;

    final private JFrame frame;

    private boolean isWin;

    // Define an overlay panel as a class-level variable
    private JPanel overlayPanel;

    private boolean isIntermission = false;

    public CardGameGUI(CardGame game, MasterFrame window) {
        frame = window.frame;
        this.game = game;
        cardButtons = new ArrayList<>();
        setup();
    }

    private void setup() {
        frame.setLayout(new BorderLayout());

        // Create and set bounds for the layered pane
        layeredPane = new JLayeredPane();
        layeredPane.setBounds(0, 0, frame.getWidth(), frame.getHeight());  // Set size to fill the frame
        frame.add(layeredPane, BorderLayout.CENTER);  // Add layeredPane to the frame
    
        // Set preferred size for gridPanel and add it to the layeredPane
        JPanel gridPanel = new JPanel(new GridBagLayout());
        layeredPane.add(gridPanel, JLayeredPane.DEFAULT_LAYER);
        gridPanel.setBounds(0, 0, layeredPane.getWidth(), layeredPane.getHeight());  // Ensure gridPanel fills the layeredPane

        int targetWidth;
        int columns;
        if (game.difficulty != 2) { // Easy or Medium
            targetWidth = 240;  // Size for 8 cards
            columns = 4;  // 2 rows with 4 columns
        } else { // Hard (difficulty == 2)
            targetWidth = 200;  // Smaller size for 12 cards
            columns = 6;  // 2 rows with 6 columns
        }

        // Load the card back image and resize it (only once)
        ImageIcon cardIcon = new ImageIcon("C:/FabAcademy/CSA/Project/CardBack.png");
        int originalWidth = cardIcon.getIconWidth();
        int originalHeight = cardIcon.getIconHeight();

        // Maintain aspect ratio while resizing the card back
        int targetHeight = (targetWidth * originalHeight) / originalWidth;
        Image scaledImage = cardIcon.getImage().getScaledInstance(targetWidth, targetHeight, Image.SCALE_SMOOTH);
        resizedCardIcon = new ImageIcon(scaledImage);  // Store resized card back

        // Create card buttons
        for (int i = 0; i < game.getCards().size(); i++) {
            JButton cardButton = new JButton();
            cardButton.setIcon(resizedCardIcon);  // Set the resized card back
            cardButton.setOpaque(false);
            cardButton.setContentAreaFilled(false);
            cardButton.setBorderPainted(false);

            // Set preferred size based on resized image size
            cardButton.setPreferredSize(new Dimension(targetWidth, targetHeight));

            // Add directly to the gridPanel with GridBagConstraints
            GridBagConstraints gbc = new GridBagConstraints();
            gbc.gridx = i % columns;  // Set column based on the number of columns
            gbc.gridy = i / columns;  // Set row based on index
            if (columns == 6) gbc.insets = new Insets(20, 10, 20, 10);
            else gbc.insets = new Insets(20, 30, 20, 30);
            gridPanel.add(cardButton, gbc);

            // Add ActionListener to the button
            cardButton.addActionListener(new CardListener(i));
            cardButtons.add(cardButton);
        }

        // Define and position the menu button
        JButton menuButton = new MenuButton("MainMenu", "setup", "MAIN MENU");
        menuButton.setBounds(layeredPane.getWidth() - 150, 10, 130, 50); // Top-right corner positioning
        layeredPane.add(menuButton, JLayeredPane.PALETTE_LAYER); // Add menuButton to a higher layer

        // Add a mouse listener to hide the focus cards when the screen is clicked
        layeredPane.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                hideFocusCards();  // Hide the focus cards on click
            }
        });
        frame.pack(); // Adjust size based on components
        updateScreen();
    } 

    private class CardListener implements ActionListener {
        private final int cardNumber;
        public CardListener(int num) {
            cardNumber = num;
        }
    
        @Override
        public void actionPerformed(ActionEvent e) {
            // Ignore clicks if in intermission
            if (isIntermission) {
                return;
            }
    
            if (game.cardsSelected == 0) {
                game.cardNum1 = cardNumber;
            } else if (game.cardsSelected == 1) {
                if (cardNumber == game.cardNum1) {
                    return;
                }
    
                game.cardNum2 = cardNumber;
                isIntermission = true; // Start intermission
                updateScreen();
    
                Timer timer = new Timer(1000, event -> {
                    isWin = game.checkMatch();
                    game.cardsSelected = 0; // Reset after checking match
                    updateScreen();
                    isIntermission = false; // End intermission
                });
                timer.setRepeats(false); // Ensure it only runs once
                timer.start();
            }
            game.cardsSelected += 1;
            game.flipCard(cardNumber);
            updateScreen();
        }
    }    
    
    private void updateScreen() {
        for (int i = 0; i < cardButtons.size(); i++) {
            Card card = game.getCard(i);
            if (!card.isFlipped) {
                // Use the combined image with the back image and the front image
                ImageIcon frontIcon = new ImageIcon(card.getImage());
                ImageIcon combinedIcon = combineImages(frontIcon, resizedCardIcon);
                cardButtons.get(i).setIcon(combinedIcon);
                //cardButtons.get(i).setText(card.getPerson());  // Set person name if needed
    
            } else {
                cardButtons.get(i).setText("");
                cardButtons.get(i).setIcon(resizedCardIcon);  // Show the card back when flipped
            }
        }
    }

    public void disableCardButtons(int cardNum1, int cardNum2) {
        cardButtons.get(cardNum1).setEnabled(false);
        cardButtons.get(cardNum2).setEnabled(false);
    }   

    public void showWinMessage() {

        JLabel winMessage = new JLabel("YOU WIN!");
        winMessage.setBounds(600, 450, 1000, 100);
        winMessage.setFont(new Font("Arial", Font.BOLD, 80));

        layeredPane.add(winMessage, JLayeredPane.PALETTE_LAYER);

        layeredPane.revalidate();
        layeredPane.repaint();
    }

    private ImageIcon combineImages(ImageIcon frontIcon, ImageIcon backIcon) {
        int backWidth = backIcon.getIconWidth();
        int backHeight = backIcon.getIconHeight();
    
        // Create a blank image with the same size as the back image
        BufferedImage combined = new BufferedImage(backWidth, backHeight, BufferedImage.TYPE_INT_ARGB);
        Graphics g = combined.getGraphics();
    
        // Draw the back image
        g.drawImage(backIcon.getImage(), 0, 0, null);
        
        // Scale down the front image
        int frontWidth = (int) (backWidth * 0.8);  // Scale down to 80% of the back width
        int frontHeight = (int) (frontWidth * frontIcon.getIconHeight() / (double) frontIcon.getIconWidth());  // Maintain aspect ratio
        Image scaledFrontImage = frontIcon.getImage().getScaledInstance(frontWidth, frontHeight, Image.SCALE_SMOOTH);
        
        // Draw the scaled front image on top of the back image
        g.drawImage(scaledFrontImage, (backWidth - frontWidth) / 2, (backHeight - frontHeight) / 2, null); // Center the front image
        
        g.dispose();  // Clean up graphics context
        return new ImageIcon(combined);
    }
    
    public void displayCards(Card card1, Card card2) {
        // Create the overlay panel to block interactions with other elements
        overlayPanel = new JPanel();
        overlayPanel.setOpaque(false);  // Keep it transparent
        overlayPanel.setBounds(0, 0, frame.getWidth(), frame.getHeight());
        layeredPane.add(overlayPanel, JLayeredPane.MODAL_LAYER);  // Add overlay above the card buttons

        // Add a mouse listener to close focus images when clicking anywhere on the overlay
        overlayPanel.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                hideFocusCards();  // Hide focus images and remove overlay
                if (isWin) showWinMessage();
            }
        });

        ImageIcon image1 = new ImageIcon(card1.getImage());
        ImageIcon image2 = new ImageIcon(card2.getImage());

        int[] dimensions1 = adjustDimension(image1, 450, 350);
        int[] dimensions2 = adjustDimension(image2, 450, 350);

        focusCard1 = new JLabel(new ImageIcon(image1.getImage().getScaledInstance(dimensions1[0], dimensions1[1], Image.SCALE_SMOOTH)));
        focusCard2 = new JLabel(new ImageIcon(image2.getImage().getScaledInstance(dimensions2[0], dimensions2[1], Image.SCALE_SMOOTH)));

        int centerX = 800, centerY = 450;
        int displacement = 350;

        int xCenter1 = centerX - displacement - (dimensions1[0] / 2);
        int xCenter2 = centerX + displacement - (dimensions2[0] / 2);
        int yCenter1 = centerY - (dimensions1[1] / 2);
        int yCenter2 = centerY - (dimensions2[1] / 2);

        focusCard1.setBounds(xCenter1, yCenter1, dimensions1[0], dimensions1[1]);
        focusCard2.setBounds(xCenter2, yCenter2, dimensions2[0], dimensions2[1]);

        nameLabel = new JLabel("THIS PERSON IS: " + card1.getPerson().toUpperCase(), SwingConstants.CENTER);
        nameLabel.setBounds(300, 700, 1000, 50);
        nameLabel.setFont(new Font("Arial", Font.BOLD, 50));

        layeredPane.add(focusCard1, JLayeredPane.PALETTE_LAYER);
        layeredPane.add(focusCard2, JLayeredPane.PALETTE_LAYER);
        layeredPane.add(nameLabel, JLayeredPane.PALETTE_LAYER);

        layeredPane.revalidate();
        layeredPane.repaint();
    }
    
    public void displayCards(Card card) {
        // Create the overlay panel to block interactions with other elements
        overlayPanel = new JPanel();
        overlayPanel.setOpaque(false);  // Keep it transparent
        overlayPanel.setBounds(0, 0, frame.getWidth(), frame.getHeight());
        layeredPane.add(overlayPanel, JLayeredPane.MODAL_LAYER);  // Add overlay above the card buttons

        // Add a mouse listener to close focus images when clicking anywhere on the overlay
        overlayPanel.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                hideFocusCards();  // Hide focus images and remove overlay
                if (isWin) showWinMessage();
            }
        });
        
        ImageIcon image = new ImageIcon(card.getImage());
        int[] dimensions = adjustDimension(image, 450, 350);

        focusCard1 = new JLabel(new ImageIcon(image.getImage().getScaledInstance(dimensions[0], dimensions[1], Image.SCALE_SMOOTH)));
        focusCard1.setBounds(800 - (dimensions[0] / 2), 450 - (dimensions[1] / 2), dimensions[0], dimensions[1]);

        nameLabel = new JLabel("THIS PERSON IS: " + card.getPerson().toUpperCase(), SwingConstants.CENTER);
        nameLabel.setBounds(300, 700, 1000, 50);
        nameLabel.setFont(new Font("Arial", Font.BOLD, 50));

        layeredPane.add(focusCard1, JLayeredPane.PALETTE_LAYER);
        layeredPane.add(nameLabel, JLayeredPane.PALETTE_LAYER);

        layeredPane.revalidate();
        layeredPane.repaint();
    }
        

    public int[] adjustDimension(ImageIcon image, int maxWidth, int maxHeight) {
        int originalWidth = image.getIconWidth();
        int originalHeight = image.getIconHeight();
        int newWidth = originalWidth;
        int newHeight = originalHeight;
    
        // If the image is smaller than the max width or height, scale up to fit the closest boundary
        if (originalWidth < maxWidth && originalHeight < maxHeight) {
            double widthRatio = maxWidth / (double) originalWidth;
            double heightRatio = maxHeight / (double) originalHeight;
    
            // Scale by the larger of the two ratios to fit the closest boundary
            double scaleFactor = Math.max(widthRatio, heightRatio);
            newWidth = (int) (originalWidth * scaleFactor);
            newHeight = (int) (originalHeight * scaleFactor);
        } else {
            // Existing scaling logic for larger images
            if (originalWidth > maxWidth) {
                newWidth = maxWidth;
                newHeight = (newWidth * originalHeight) / originalWidth;
            }
    
            if (newHeight > maxHeight) {
                newHeight = maxHeight;
                newWidth = (newHeight * originalWidth) / originalHeight;
            }
        }
    
        return new int[]{newWidth, newHeight};
    }       

    // Modify hideFocusCards to remove the overlay when hiding focus images
    public void hideFocusCards() {
        if (focusCard1 != null) {
            layeredPane.remove(focusCard1);
            focusCard1 = null;
        }
        if (focusCard2 != null) {
            layeredPane.remove(focusCard2);
            focusCard2 = null;
        }
        if (nameLabel != null) {
            layeredPane.remove(nameLabel);
            nameLabel = null;
        }
        if (overlayPanel != null) {
            layeredPane.remove(overlayPanel);  // Remove the overlay to allow card interaction
            overlayPanel = null;
        }
        layeredPane.repaint();
    }
}