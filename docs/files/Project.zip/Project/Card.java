package Project;

import java.awt.image.BufferedImage;

/**
 * Represents a card in the game. Each card is associated with an image, 
 * a person's name, and a unique card number.
 */
public class Card {
    public boolean isFlipped = true; // Indicates whether the card is flipped
    public boolean isRemoved;       // Indicates whether the card is removed from play

    private final BufferedImage cardImage; // The image displayed on the card
    private final String person;           // The name associated with the card
    public int cardNumber;                 // The unique identifier for the card

    /**
     * Constructs a Card object with the specified image, associated person, and card number.
     * 
     * @param image the image on the card
     * @param person the name associated with the card
     * @param cardNumber the unique identifier for the card
     */
    public Card(BufferedImage image, String person, int cardNumber) {
        this.cardImage = image;
        this.person = person;
        this.cardNumber = cardNumber;
        this.isRemoved = false;
    }

    /**
     * Gets the name associated with the card.
     * 
     * @return the associated person's name
     */
    public String getPerson() {
        return person;
    }

    /**
     * Gets the image displayed on the card.
     * 
     * @return the card's image
     */
    public BufferedImage getImage() {
        return cardImage;
    }

    /**
     * Flips the card, toggling its flipped state.
     */
    public void flipCard() {
        isFlipped = !isFlipped;
    }

    /**
     * Checks if this card matches another card based on the associated person's name.
     * 
     * @param otherCard the card to compare with
     * @return true if the cards match, false otherwise
     */
    public boolean matches(Card otherCard) {
        return person.equals(otherCard.getPerson());
    }
}
