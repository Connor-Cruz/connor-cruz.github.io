package Project;

import java.awt.*;
import javax.swing.*;

public class MenuGUI {
    private final JFrame frame;

    public MenuGUI(MasterFrame window) {
        this.frame = window.frame;
    }

    public void setup() {
        // Clear existing components
        frame.getContentPane().removeAll();
        frame.setLayout(new BorderLayout());

        // Title at the top
        JLabel titleLabel = new JLabel("MEMORIZATION ACTIVITIES", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 70));
        titleLabel.setForeground(Color.BLACK);
        titleLabel.setBorder(BorderFactory.createEmptyBorder(50, 0, 50, 0));

        // Main button panel with absolute positioning
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(null); // Absolute positioning for flexible placement
        mainPanel.setBackground(new Color(60, 63, 65)); // Dark gray background

        // Create buttons
        JButton cardGame = new MenuButton("DiffSelect", "setup", "CARD GAME", 1);
        JButton imageLibrary = new MenuButton("ImageLibrary", "setup", "IMAGE LIBRARY");
        JButton quizGame = new MenuButton("DiffSelect", "setup", "QUIZ GAME", 2);
        JButton familyControls = new MenuButton("FamilyControls", "setup", "FAMILY CONTROLS");

        // Button sizes
        Dimension largeButtonSize = new Dimension(600, 200);
        Dimension smallButtonSize = new Dimension(200, 50);

        // Get frame dimensions
        int frameWidth = frame.getWidth();
        int frameHeight = frame.getHeight();

        // Calculate positions to center the buttons
        int centerX = frameWidth / 2;
        int centerY = frameHeight / 2 - 100;

        cardGame.setBounds(centerX - largeButtonSize.width - 20, centerY - largeButtonSize.height,largeButtonSize.width, largeButtonSize.height);
        imageLibrary.setBounds(centerX + 20, centerY - largeButtonSize.height, largeButtonSize.width, largeButtonSize.height);
        quizGame.setBounds(centerX - (largeButtonSize.width / 2), centerY + 20, largeButtonSize.width, largeButtonSize.height);

        cardGame.setFont(new Font("Arial", Font.BOLD, 70));
        imageLibrary.setFont(new Font("Arial", Font.BOLD, 70)); 
        quizGame.setFont(new Font("Arial", Font.BOLD, 70));

        // Position family controls in bottom-right corner
        familyControls.setBounds(frameWidth - smallButtonSize.width - 50, frameHeight - smallButtonSize.height - 200, smallButtonSize.width, smallButtonSize.height);

        // Add components to the main panel
        mainPanel.add(cardGame);
        mainPanel.add(imageLibrary);
        mainPanel.add(quizGame);
        mainPanel.add(familyControls);

        // Add title and main panel to the frame
        frame.add(titleLabel, BorderLayout.NORTH);
        frame.add(mainPanel, BorderLayout.CENTER);

        frame.revalidate();
        frame.repaint();
    }
}
