package Project;

import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

/**
 * Represents the logic and state for a memory card-matching game.
 */
public class CardGame {
    public int difficulty; // Game difficulty level
    private final List<Card> cards; // List of all cards in the game
    public int cardsSelected; // Number of currently selected cards

    private Card card1, card2; // The two selected cards for comparison
    public int cardNum1, cardNum2; // Indices of the selected cards

    private CardGameGUI gui; // Reference to the GUI for the game
    private final MasterFrame window; // The main application window

    /**
     * Constructs a CardGame object.
     * 
     * @param window the main application window
     * @param difficulty the difficulty level of the game
     */
    public CardGame(MasterFrame window, int difficulty) {
        cards = new ArrayList<>();
        this.window = window;
        this.difficulty = difficulty;
    }

    /**
     * Returns the list of cards in the game.
     * 
     * @return the list of cards
     */
    public List<Card> getCards() {
        return cards;
    }

    /**
     * Retrieves a card by its index.
     * 
     * @param i the index of the card
     * @return the card at the specified index
     */
    public Card getCard(int i) {
        return cards.get(i);
    }

    /**
     * Initializes the game by assigning images to cards, shuffling them, 
     * and setting up the GUI.
     */
    public void initializeGame() {
        assignImages();
        shuffleCards();
        gui = new CardGameGUI(this, window);
    }

    /**
     * Assigns images to cards based on the game difficulty.
     */
    private void assignImages() {
        int amount = (difficulty == 0 || difficulty == 1) ? 8 : 12;

        ImageLibrary library = new ImageLibrary();
        int[] usedIndices = new int[library.people.size()];
        java.util.Arrays.fill(usedIndices, -1);

        Random rand = new Random();
        for (int i = 0; i < amount / 2; i++) {
            int randomIndex;
            while (true) {
                randomIndex = rand.nextInt(library.people.size());
                if (!inArray(randomIndex, usedIndices)) {
                    usedIndices[i] = randomIndex;
                    break;
                }
            }

            Person cardPerson = library.people.get(randomIndex);
            int ind1, ind2;

            if (cardPerson.getImageAmount() > 1 && difficulty != 0) {
                ind1 = rand.nextInt(cardPerson.getImageAmount() - 1);
                do {
                    ind2 = rand.nextInt(cardPerson.getImageAmount());
                } while (ind1 == ind2);
            } else {
                ind1 = 0;
                ind2 = 0;
            }

            BufferedImage image1 = cardPerson.getImage(ind1);
            BufferedImage image2 = cardPerson.getImage(ind2);
            cards.add(new Card(image1, cardPerson.name, i * 2 + 1));
            cards.add(new Card(image2, cardPerson.name, i * 2 + 2));
        }
    }

    /**
     * Shuffles the list of cards.
     */
    private void shuffleCards() {
        Collections.shuffle(cards);
    }

    /**
     * Checks if all cards have been removed, indicating a win.
     * 
     * @return true if the game is won, false otherwise
     */
    private boolean checkWin() {
        for (Card card : cards) {
            if (!card.isRemoved) {
                return false;
            }
        }
        return true;
    }

    /**
     * Checks if two selected cards match and handles game state updates.
     * 
     * @return true if the game is won after the match, false otherwise
     */
    public boolean checkMatch() {
        boolean isWin = false;

        card1 = getCard(cardNum1);
        card2 = getCard(cardNum2);

        if (card1.matches(card2)) {
            gui.disableCardButtons(cardNum1, cardNum2);

            if (difficulty == 0 || card1.getImage().equals(card2.getImage())) {
                gui.displayCards(card1);
            } else {
                gui.displayCards(card1, card2);
            }

            removeCard(card1);
            removeCard(card2);

            if (checkWin()) {
                System.out.println("Yay! All pairs matched!");
                isWin = true;
            }
        } else {
            System.out.println("These cards don't match.");
        }

        flipCard(cardNum1);
        flipCard(cardNum2);

        return isWin;
    }

    /**
     * Marks a card as removed from the game.
     * 
     * @param card the card to remove
     */
    private void removeCard(Card card) {
        card.isRemoved = true;
    }

    /**
     * Flips the state of a card.
     * 
     * @param cardNumber the index of the card to flip
     */
    public void flipCard(int cardNumber) {
        cards.get(cardNumber).flipCard();
    }

    /**
     * Checks if an element exists in an array.
     * 
     * @param element the element to check
     * @param array the array to search
     * @return true if the element is found, false otherwise
     */
    private boolean inArray(int element, int[] array) {
        for (int i : array) {
            if (i == element) return true;
        }
        return false;
    }
}
