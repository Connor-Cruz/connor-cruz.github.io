package Project;

import java.awt.*;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLayeredPane;
import javax.swing.JTextField;

public class QuizGameGUI {
    private final JFrame frame;
    private final QuizGame game;
    private JTextField personField;
    private JLayeredPane layeredPane;

    public QuizGameGUI(MasterFrame window, int diff) {
        frame = window.frame;
        game = new QuizGame();
    }

    public void setup() {
        // Set up the frame properties
        frame.getContentPane().removeAll();  // Clear existing components

        // Initialize JLayeredPane and set its bounds
        layeredPane = new JLayeredPane();
        layeredPane.setPreferredSize(new Dimension(frame.getWidth(), frame.getHeight()));
        layeredPane.setBounds(0, 0, frame.getWidth(), frame.getHeight());  // Set size to fill the frame

        // Menu button in the top right corner
        JButton menuButton = new MenuButton("MainMenu", "setup", "MAIN MENU");
        menuButton.setBounds(50, 10, 130, 50);
        layeredPane.add(menuButton);

        // Add the layered pane to the frame and refresh the display
        frame.add(layeredPane);
        frame.pack();
        frame.revalidate();
        frame.repaint();
    }
}
