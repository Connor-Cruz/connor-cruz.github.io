package Project;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javax.swing.*;

public class ImageLibraryGUI {
    private JButton toggleButton;
    private JButton menuButton;
    private final JFrame frame;
    private final ImageLibrary imageLibrary;
    private final JLayeredPane layeredPane;
    private boolean toggleState = true;

    private static final int MAX_IMAGE_WIDTH = 400;
    private static final int MAX_IMAGE_HEIGHT = 350;

    public ImageLibraryGUI(MasterFrame window) {
        this.frame = window.frame;
        this.imageLibrary = new ImageLibrary();
        this.layeredPane = new JLayeredPane();
    }

    public void setup() {
        frame.setLayout(new BorderLayout());  // Ensure frame uses BorderLayout for simplicity
        frame.add(layeredPane, BorderLayout.CENTER);
        layeredPane.setPreferredSize(new Dimension(frame.getWidth(), frame.getHeight()));
        layeredPane.setBounds(0, 0, frame.getWidth(), frame.getHeight());  // Set size to fill the frame

        // Initialize the toggle button
        toggleButton = new JButton("VIEW BY PERSON");
        toggleButton.addActionListener(e -> switchButton());
        toggleButton.setBounds(50, 10, 200, 50);
        layeredPane.add(toggleButton, JLayeredPane.PALETTE_LAYER);  // Ensure button is on top layer

        menuButton = new MenuButton("MainMenu", "setup", "MAIN MENU");
        menuButton.setBounds(layeredPane.getWidth() - 150, 10, 130, 50);
        layeredPane.add(menuButton, JLayeredPane.PALETTE_LAYER);

        // Start in imageView mode
        imageView();
        frame.revalidate();
        frame.repaint();
    }

    private void switchButton() {
        layeredPane.removeAll();  // Clear the pane's current components
        layeredPane.add(toggleButton, JLayeredPane.PALETTE_LAYER);  // Re-add the toggle button
        layeredPane.add(menuButton, JLayeredPane.PALETTE_LAYER);
        
        if (toggleState) {
            toggleButton.setText("VIEW BY IMAGE");
            personView();
        } else {
            toggleButton.setText("VIEW BY PERSON");
            imageView();
        }
        toggleState = !toggleState;

        layeredPane.revalidate();
        layeredPane.repaint();
        frame.revalidate();
        frame.repaint();
    }

    private void personView() {
        // Panel to hold all person sections horizontally
        JPanel personPanel = new JPanel();
        personPanel.setLayout(new BoxLayout(personPanel, BoxLayout.X_AXIS)); // Horizontal stacking for people
        personPanel.setBackground(Color.WHITE);
    
        for (Person person : imageLibrary.getPeople()) {
            // Create a section for each person
            JPanel personSection = new JPanel();
            personSection.setLayout(new BoxLayout(personSection, BoxLayout.Y_AXIS)); // Vertical stacking for person section
            personSection.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20)); // Padding for the section
            personSection.setBackground(Color.WHITE);
    
            // Centered name label
            JLabel personNameLabel = new JLabel(person.name.toUpperCase());
            personNameLabel.setFont(new Font("Arial", Font.BOLD, 30));
            personNameLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
            personNameLabel.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0)); // Padding above and below
            personSection.add(personNameLabel);
    
            // Horizontal layout for images
            JPanel imageRow = new JPanel();
            imageRow.setLayout(new BoxLayout(imageRow, BoxLayout.X_AXIS));
            imageRow.setBackground(Color.WHITE);
            imageRow.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10)); // Padding for the row
    
            for (BufferedImage image : person.getImages()) {
                // Create a box for each image
                JPanel imageContainer = new JPanel();
                imageContainer.setLayout(new BorderLayout());
                imageContainer.setPreferredSize(new Dimension(600, 600)); // Larger square-like box
                imageContainer.setMaximumSize(new Dimension(600, 600));
                imageContainer.setBorder(BorderFactory.createLineBorder(Color.GRAY, 2)); // Box border
                imageContainer.setBackground(Color.LIGHT_GRAY);
    
                // Add scaled image inside the box
                JLabel imageLabel = new JLabel(new ImageIcon(resizeAndCenterImage(image)));
                imageLabel.setHorizontalAlignment(SwingConstants.CENTER);
                imageLabel.setVerticalAlignment(SwingConstants.CENTER);
                imageContainer.add(imageLabel, BorderLayout.CENTER);
    
                imageRow.add(Box.createRigidArea(new Dimension(10, 0))); // Space between images
                imageRow.add(imageContainer);
            }
    
            imageRow.add(Box.createRigidArea(new Dimension(10, 0))); // Padding at the end of the row
            personSection.add(imageRow);
    
            personPanel.add(personSection);
        }
    
        JScrollPane mainScrollPane = new JScrollPane(personPanel);
        mainScrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        mainScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_NEVER);
        mainScrollPane.getHorizontalScrollBar().setUnitIncrement(16);
        mainScrollPane.getHorizontalScrollBar().setBlockIncrement(50);
        mainScrollPane.setBounds(0, 0, frame.getWidth(), frame.getHeight());
    
        layeredPane.add(mainScrollPane, JLayeredPane.DEFAULT_LAYER);
        layeredPane.revalidate();
        layeredPane.repaint();
    }        
    
    private void imageView() {
        JPanel imagePanel = new JPanel();
        imagePanel.setLayout(new GridLayout(0, 2, 20, 20)); // Grid layout with 2 columns and vertical spacing
    
        // Collect all images and their respective names
        List<ImageData> allImages = new ArrayList<>();
        for (Person person : imageLibrary.getPeople()) {
            String personName = person.name.toUpperCase();
            List<BufferedImage> images = person.getImages();
            for (BufferedImage image : images) {
                allImages.add(new ImageData(personName, image));
            }
        }
    
        // Shuffle the images for a scrambled display
        Collections.shuffle(allImages);
    
        // Add images in a consistent box size with name and image centered
        for (ImageData imageData : allImages) {
            JLabel imageLabel = new JLabel(new ImageIcon(resizeAndCenterImage(imageData.image)));
            imageLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
    
            JLabel nameLabel = new JLabel(imageData.name);
            nameLabel.setFont(new Font("Arial", Font.BOLD, 40)); // Larger, bold font
            nameLabel.setAlignmentX(Component.CENTER_ALIGNMENT); // Center the name
    
            JPanel imageContainer = new JPanel();
            imageContainer.setLayout(new BoxLayout(imageContainer, BoxLayout.Y_AXIS));
            imageContainer.setPreferredSize(new Dimension(300, 400)); // Box size
            imageContainer.setMaximumSize(new Dimension(300, 400));
            imageContainer.setBorder(BorderFactory.createLineBorder(Color.GRAY, 2)); // Box border
            imageContainer.setBackground(Color.WHITE); // Box background
    
            imageContainer.add(Box.createVerticalGlue()); // Center content vertically
            imageContainer.add(imageLabel);
            imageContainer.add(Box.createRigidArea(new Dimension(0, 5))); // Space between image and name
            imageContainer.add(nameLabel);
            imageContainer.add(Box.createVerticalGlue()); // Center content vertically
    
            imagePanel.add(imageContainer);
        }
    
        JScrollPane mainScrollPane = new JScrollPane(imagePanel);
        mainScrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        mainScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        mainScrollPane.getVerticalScrollBar().setUnitIncrement(16);
        mainScrollPane.getVerticalScrollBar().setBlockIncrement(50);
        mainScrollPane.setBounds(0, 0, frame.getWidth(), frame.getHeight());
    
        layeredPane.add(mainScrollPane, JLayeredPane.DEFAULT_LAYER);
        layeredPane.revalidate();
        layeredPane.repaint();
    }       

    // Helper class for storing image and name pairs
    private static class ImageData {
        String name;
        BufferedImage image;

        ImageData(String name, BufferedImage image) {
            this.name = name;
            this.image = image;
        }
    }

    private Image resizeAndCenterImage(BufferedImage originalImage) {
        int originalWidth = originalImage.getWidth();
        int originalHeight = originalImage.getHeight();

        int newWidth = originalWidth;
        int newHeight = originalHeight;
        if (originalWidth > MAX_IMAGE_WIDTH || originalHeight > MAX_IMAGE_HEIGHT) {
            double widthRatio = (double) MAX_IMAGE_WIDTH / originalWidth;
            double heightRatio = (double) MAX_IMAGE_HEIGHT / originalHeight;
            double scaleFactor = Math.min(widthRatio, heightRatio);
            newWidth = (int) (originalWidth * scaleFactor);
            newHeight = (int) (originalHeight * scaleFactor);
        }

        Image scaledImage = originalImage.getScaledInstance(newWidth, newHeight, Image.SCALE_SMOOTH);

        BufferedImage centeredImage = new BufferedImage(MAX_IMAGE_WIDTH, MAX_IMAGE_HEIGHT, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2d = centeredImage.createGraphics();
        int x = (MAX_IMAGE_WIDTH - newWidth) / 2;
        int y = (MAX_IMAGE_HEIGHT - newHeight) / 2;

        g2d.drawImage(scaledImage, x, y, null);
        g2d.dispose();

        return centeredImage;
    }
}
