package Project;

import javax.swing.JButton;

public class MenuButton extends JButton {
    public MenuButton(String objectName, String method, String text) {
        Object obj = MenuNavigator.getObject(objectName);
        addActionListener(e -> MenuNavigator.navigateTo(obj, method));
        setText(text);
    }
    public MenuButton(String objectName, String method, String text, int specification) {
        MenuNavigator.createDiffSelect(specification);
        Object obj = MenuNavigator.getObject(objectName);
        addActionListener(e -> MenuNavigator.navigateTo(obj, method));
        setText(text);
    }
}