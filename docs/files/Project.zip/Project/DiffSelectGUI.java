package Project;

import java.awt.*;
import javax.swing.*;

public class DiffSelectGUI {
    private final JFrame frame;
    private final int game;

    public DiffSelectGUI(MasterFrame window, int gameNum) {
        frame = window.frame;
        game = gameNum;
    }

    public void setup() {
        // Clear existing components
        frame.getContentPane().removeAll();
        frame.setLayout(new BorderLayout());

        // Title at the top
        JLabel titleLabel = new JLabel("DIFFICULTY SELECT", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 70));
        titleLabel.setForeground(Color.BLACK);
        titleLabel.setBorder(BorderFactory.createEmptyBorder(50, 0, 50, 0));

        // Main panel for the difficulty buttons
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(null);
        mainPanel.setBackground(new Color(60, 63, 65)); // Dark gray background

        // Menu button in the top-right corner
        JButton menuButton = new MenuButton("MainMenu", "setup", "MAIN MENU");
        Dimension menuButtonSize = new Dimension(130, 50);
        menuButton.setBounds(frame.getWidth() - menuButtonSize.width - 20, 20, 
                              menuButtonSize.width, menuButtonSize.height);

        // Difficulty buttons
        JButton easyButton = new JButton("EASY");
        JButton mediumButton = new JButton("MEDIUM");
        JButton hardButton = new JButton("HARD");

        Dimension buttonSize = new Dimension(600, 200);
        int centerX = frame.getWidth() / 2;
        int centerY = frame.getHeight() / 2 - 100;

        // Calculate triangle positions
        int offset = 150; // Distance between buttons in the triangle
        easyButton.setBounds(centerX - buttonSize.width / 2, centerY - offset, buttonSize.width, buttonSize.height);
        mediumButton.setBounds(centerX - offset - buttonSize.width + 120, centerY + offset / 2, buttonSize.width, buttonSize.height);
        hardButton.setBounds(centerX + offset - 120, centerY + offset / 2, buttonSize.width, buttonSize.height);

        easyButton.setFont(new Font("Arial", Font.BOLD, 70));
        mediumButton.setFont(new Font("Arial", Font.BOLD, 70));
        hardButton.setFont(new Font("Arial", Font.BOLD, 70));

        // Add action listeners
        easyButton.addActionListener(e -> startGame(0));
        mediumButton.addActionListener(e -> startGame(1));
        hardButton.addActionListener(e -> startGame(2));

        // Add components to the main panel
        mainPanel.add(easyButton);
        mainPanel.add(mediumButton);
        mainPanel.add(hardButton);
        mainPanel.add(menuButton);

        // Add title and main panel to the frame
        frame.add(titleLabel, BorderLayout.NORTH);
        frame.add(mainPanel, BorderLayout.CENTER);

        frame.revalidate();
        frame.repaint();
    }

    private void startGame(int diff) {
        String name;
        String method;

        if (game == 1) {
            MenuNavigator.createCardGame(diff);
            name = "CardGame";
            method = "initializeGame";
        } else {
            MenuNavigator.createQuizGame(diff);
            name = "QuizGame";
            method = "setup";
        }

        Object obj = MenuNavigator.getObject(name);
        MenuNavigator.navigateTo(obj, method);
    }
}
