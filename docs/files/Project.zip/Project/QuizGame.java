package Project;

import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class QuizGame {
    private List<Question> questions;
    private int currentScore;
    private final ImageLibrary imageLibrary; // Reference to your existing ImageLibrary

    public QuizGame() {
        imageLibrary = new ImageLibrary();
        questions = new ArrayList<>();
        currentScore = 0;
    }

    // Generates a "Who is this?" question
    public IdentifyPersonQuestion generateWhoIsThisQuestion() {
        Person randomPerson = imageLibrary.getRandomPerson();
        BufferedImage image = randomPerson.getRandomImage();
        List<String> options = imageLibrary.getRandomNames(4); // 4 options total
        if (!options.contains(randomPerson.name)) {
            options.set(new Random().nextInt(options.size()), randomPerson.name);
        }

        return new IdentifyPersonQuestion(
            "Who is this?", 
            image, 
            randomPerson.name
        );
    }

    // Generates a "Select the correct image for [Person]" question
    public IdentifyImageQuestion generateSelectImageForPersonQuestion() {
        Person randomPerson = imageLibrary.getRandomPerson();
        List<BufferedImage> images = imageLibrary.getRandomImages(4); // 4 images total
        BufferedImage correctImage = randomPerson.getRandomImage();
        if (!images.contains(correctImage)) {
            images.set(new Random().nextInt(images.size()), correctImage);
        }

        return new IdentifyImageQuestion(
            "Select the correct image for " + randomPerson.name,
            images,
            correctImage
        );
    }

    // Add a question to the quiz
    public void addQuestion(Question question) {
        questions.add(question);
    }

    // Evaluate an answer
    public boolean evaluateAnswer(Question question, String userAnswer) {
        boolean isCorrect = question.getCorrectAnswer().equals(userAnswer);
        if (isCorrect) {
            currentScore++;
        }
        return isCorrect;
    }

    // Evaluate an answer for image questions
    public boolean evaluateAnswer(IdentifyImageQuestion question, BufferedImage userAnswer) {
        boolean isCorrect = question.getCorrectAnswerImage().equals(userAnswer);
        if (isCorrect) {
            currentScore++;
        }
        return isCorrect;
    }

    // Getter for the current score
    public int getCurrentScore() {
        return currentScore;
    }

    // Getter for all questions
    public List<Question> getQuestions() {
        return questions;
    }
}
