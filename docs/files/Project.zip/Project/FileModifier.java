package Project;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

// Class for file modification functionality
public class FileModifier {
    private final static String PATH = "C:/FabAcademy/CSA/Project/data.txt";

    // Adds a person to the file if they do not already exist
    public void addPerson(String person) {
        boolean personExists = false;

        // Read the file to check if the person already exists
        try (BufferedReader br = new BufferedReader(new FileReader(PATH))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (line.trim().equals("#" + person)) {
                    personExists = true;  // Person already exists
                }
            }
        } catch (IOException e) {
            System.out.println("Error reading the file.");
        }

        // If the person doesn't exist, add them to the end of the file
        if (!personExists) {
            try (FileWriter writer = new FileWriter(PATH, true)) {  // Append mode
                writer.write("\n#" + person + "\n");
                System.out.println(person + " added to the file.");
            } catch (IOException e) {
                System.out.println("Error writing to the file.");
            }
        } else {
            System.out.println(person + " already exists in the file.");
        }
    }

    // Adds an image path under the specified person in the file, adds person if they don't exist
    public void addImage(String imagePath, String person) {
        List<String> fileLines = new ArrayList<>();
        boolean personExists = false;
        int personLineIndex = -1;

        // Read the file to find the person and their position
        try (BufferedReader br = new BufferedReader(new FileReader(PATH))) {
            String line;
            int lineIndex = 0;
            while ((line = br.readLine()) != null) {
                fileLines.add(line);  // Keep original formatting
                if (line.trim().equals("#" + person)) {
                    personExists = true;
                    personLineIndex = lineIndex;
                }
                lineIndex++;
            }
        } catch (IOException e) {
            System.out.println("Error reading the file.");
        }

        // If the person does not exist, add them first
        if (!personExists) {
            addPerson(person);  // Add the person to the file
            fileLines.add("#" + person);  // Append the person to the file content list
            personLineIndex = fileLines.size() - 1;  // Update the person's position
        }

        // Insert the image after the person's existing images
        int insertIndex = personLineIndex + 1;
        while (insertIndex < fileLines.size() && !fileLines.get(insertIndex).startsWith("#")) {
            insertIndex++;
        }

        fileLines.add(insertIndex, imagePath);

        // Write back the updated content to the file
        try (FileWriter writer = new FileWriter(PATH)) {
            for (String line : fileLines) {
                writer.write(line + "\n");
            }
            System.out.println("Image added under " + person);
        } catch (IOException e) {
            System.out.println("Error writing to the file.");
        }
    }
}