package Project;

import java.awt.image.BufferedImage;
import java.util.List;

// Abstract base class for all question types
public abstract class Question {
    private final String questionText;
    private final QuestionType type;

    public Question(String questionText, QuestionType type) {
        this.questionText = questionText;
        this.type = type;
    }

    public String getQuestionText() {
        return questionText;
    }

    public QuestionType getType() {
        return type;
    }

    // Abstract method to get the correct answer, implemented differently in subclasses
    public abstract String getCorrectAnswer();
}

// Enum for question types
enum QuestionType {
    DATE,
    PERSONAL,
    IDENTIFY_PERSON,
    IDENTIFY_IMAGE
}

// Date question class
class DateQuestion extends Question {
    private String correctAnswer;

    public DateQuestion(String questionText, String correctAnswer) {
        super(questionText, QuestionType.DATE);
        this.correctAnswer = correctAnswer;
    }

    @Override
    public String getCorrectAnswer() {
        return correctAnswer;
    }
}

// Personal question class
class PersonalQuestion extends Question {
    private List<String> options;
    private String correctAnswer;

    public PersonalQuestion(String questionText, List<String> options, String correctAnswer) {
        super(questionText, QuestionType.PERSONAL);
        this.options = options;
        this.correctAnswer = correctAnswer;
    }

    public List<String> getOptions() {
        return options;
    }

    @Override
    public String getCorrectAnswer() {
        return correctAnswer;
    }
}

// Identify person question class
class IdentifyPersonQuestion extends Question {
    private BufferedImage associatedImage;
    private String correctAnswer;

    public IdentifyPersonQuestion(String questionText, BufferedImage associatedImage, String correctAnswer) {
        super(questionText, QuestionType.IDENTIFY_PERSON);
        this.associatedImage = associatedImage;
        this.correctAnswer = correctAnswer;
    }

    public BufferedImage getAssociatedImage() {
        return associatedImage;
    }

    @Override
    public String getCorrectAnswer() {
        return correctAnswer;
    }
}

// Identify image question class
class IdentifyImageQuestion extends Question {
    private List<BufferedImage> options;
    private BufferedImage correctAnswer;

    public IdentifyImageQuestion(String questionText, List<BufferedImage> options, BufferedImage correctAnswer) {
        super(questionText, QuestionType.IDENTIFY_IMAGE);
        this.options = options;
        this.correctAnswer = correctAnswer;
    }

    public List<BufferedImage> getOptions() {
        return options;
    }

    public BufferedImage getCorrectAnswerImage() {
        return correctAnswer;
    }

    @Override
    public String getCorrectAnswer() {
        // Return a placeholder string if needed, as BufferedImage doesn't convert to a string naturally
        return "Correct answer is an image.";
    }
}

